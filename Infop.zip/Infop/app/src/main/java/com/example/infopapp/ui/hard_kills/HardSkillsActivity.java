package com.example.infopapp.ui.hard_kills;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.infopapp.R;

public class HardSkillsActivity extends AppCompatActivity {

    private SpecializationFragment specializationFragment;
    private FragmentManager manager = getSupportFragmentManager();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hard_skills);
        setTitle(R.string.HARD_SKILLS);
        specializationFragment = new SpecializationFragment();
        goToFragment(specializationFragment);
    }

    private void goToFragment(Fragment fragment){
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.hard_kills_container,fragment);
        transaction.commit();
    }
}
