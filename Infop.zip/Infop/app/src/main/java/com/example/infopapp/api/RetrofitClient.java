package com.example.infopapp.api;

public class RetrofitClient {
}
