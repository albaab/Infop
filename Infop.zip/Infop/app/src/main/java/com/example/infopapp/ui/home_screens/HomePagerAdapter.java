package com.example.infopapp.ui.home_screens;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.example.infopapp.ui.home_screens.fragments.MessagesFragment;
import com.example.infopapp.ui.home_screens.fragments.SessionsFragment;
import com.example.infopapp.ui.home_screens.fragments.home_fragment.HomeFragment;

public class HomePagerAdapter extends FragmentStatePagerAdapter {

    public HomePagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int i) {
        Fragment fragment = null;
        switch (i) {
            case 0:
                fragment = HomeFragment.newInstance();
                break;

            case 1:
                fragment = new SessionsFragment();
                break;

            case 2:
                fragment = MessagesFragment.newInstance();
                break;
        }
        return fragment;
    }

    @Override
    public int getCount() {
        return 3;
    }
}
