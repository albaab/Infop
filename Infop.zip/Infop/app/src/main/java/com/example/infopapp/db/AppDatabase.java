package com.example.infopapp.db;

public class AppDatabase {
}
