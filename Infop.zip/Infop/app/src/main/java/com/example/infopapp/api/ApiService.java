package com.example.infopapp.api;

public interface ApiService {
}
