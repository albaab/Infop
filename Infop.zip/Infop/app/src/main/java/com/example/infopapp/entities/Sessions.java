package com.example.infopapp.entities;

@Entity
public class Sessions {

    private int id;
    private String sessionTitle;
    private String sessionType;
    private String sessionInstructor;
    private String sessionDescription;
    private String sessionDate;
    private String sessionHomework;
    private Boolean sessionFeedback;
}
